package com.cg.springjwt.models;

public enum ERole {
	CUSTOMER,
    ADMIN
}
