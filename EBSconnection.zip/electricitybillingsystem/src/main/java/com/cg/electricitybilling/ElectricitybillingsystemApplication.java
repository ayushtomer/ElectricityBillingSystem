package com.cg.electricitybilling;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ElectricitybillingsystemApplication {

	public static void main(String[] args) {
		SpringApplication.run(ElectricitybillingsystemApplication.class, args); 
		
		
	}

}
