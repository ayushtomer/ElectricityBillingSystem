package com.cg.ebs;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EbsBillApplicationTests {

	@Test
	void contextLoads() {
	}

}
