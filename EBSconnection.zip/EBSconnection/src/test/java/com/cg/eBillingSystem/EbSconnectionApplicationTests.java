package com.cg.eBillingSystem;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EbSconnectionApplicationTests {

	@Test
	void contextLoads() {
	}

}
