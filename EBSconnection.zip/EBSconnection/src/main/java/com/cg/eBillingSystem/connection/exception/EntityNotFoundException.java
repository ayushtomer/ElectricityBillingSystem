package com.cg.eBillingSystem.connection.exception;


	public class EntityNotFoundException extends RuntimeException {
		/**
		 * 
		 * @param msg
		 */
		public EntityNotFoundException(String msg) {
			super(msg);
		}

	}


